// This file is no longer in use and has been deprecated in favor of Google Docs templates.
export {};
