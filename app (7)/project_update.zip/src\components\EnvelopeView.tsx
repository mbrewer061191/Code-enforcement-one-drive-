// This component is no longer in use.
// Envelope printing is now handled by generating a Google Doc from a template.
export {};
